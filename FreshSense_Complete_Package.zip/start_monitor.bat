@echo off
title FreshSense AI - Shelf Life Monitor

echo.
echo  =============================================
echo   FreshSense AI - Starting...
echo  =============================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo  Python not found! Download from python.org
    pause
    exit /b 1
)

echo  Installing required packages...
pip install pyserial scikit-learn pandas numpy flask --quiet

echo.
echo  Starting FreshSense AI...
echo  Browser will open automatically.
echo  Press Ctrl+C to stop.
echo.

python freshsense_final.py

pause
